extends Node

var main_menu: Control
var game_scene: PackedScene

func _ready():
	main_menu = $MainMenu
	game_scene = preload("res://scenes/GameScene.tscn")
	main_menu.connect("start_game", self, "_on_start_game")

func _on_start_game():
	# Hide menu, instance game scene
	main_menu.visible = false
	var game = game_scene.instantiate()
	add_child(game)
