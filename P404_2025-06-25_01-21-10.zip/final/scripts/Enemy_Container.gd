extends Node2D

func start_wave(wave_number: int):
	# TODO: spawn a number of enemies based on wave_number
	for i in range(wave_number * 2):
		var enemy = preload("res://scenes/Enemy.tscn").instantiate()
		add_child(enemy)
		enemy.start_path($Map)  # assumes Enemy.gd has a start_path() API

func _on_enemy_reached_end(enemy):
	$GameManager.on_enemy_reached_end()
	enemy.queue_free()

func _on_enemy_killed(enemy):
	$GameManager.on_enemy_killed()
	enemy.queue_free()
