extends Node2D

func _ready():
	# TODO: load tower types, handle placement input
	pass

func place_tower(position: Vector2):
	# Instantiate a tower at the grid-snapped position
	var tower = preload("res://scenes/Tower.tscn").instantiate()
	tower.position = position.snapped(Vector2(64, 64))
	add_child(tower)
