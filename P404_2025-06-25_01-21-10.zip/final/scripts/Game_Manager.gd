extends Node

signal game_over

var gold: int = 100
var health: int = 10
var wave: int = 0

func _ready():
	start_next_wave()

func start_next_wave():
	wave += 1
	# TODO: spawn enemies via EnemyContainer
	$EnemyContainer.start_wave(wave)

func on_enemy_reached_end():
	health -= 1
	if health <= 0:
		emit_signal("game_over")

func on_enemy_killed():
	gold += 10
	# update UI via USD variables or signals
