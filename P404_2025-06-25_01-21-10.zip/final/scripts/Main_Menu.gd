extends Control

signal start_game

func _ready():
	$StartButton.pressed.connect(_on_start_pressed)
	$OptionsButton.pressed.connect(_on_options_pressed)

func _on_start_pressed():
	emit_signal("start_game")

func _on_options_pressed():
	# TODO: Open options popup
	pass
